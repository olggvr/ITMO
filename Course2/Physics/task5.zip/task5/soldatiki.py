import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle
import matplotlib
matplotlib.use('TkAgg')

# Настройки
L = 10.0
inner_L = 5.0
center = np.array([L / 2, L / 2])
rows = 2           # МЕНЬШЕ рядов
spacing = 0.3      # расстояние между рядами
soldiers_per_side = 25

# Координаты сторон квадрата (вектор направления, начало)
inner_x = (L - inner_L) / 2
inner_y = (L - inner_L) / 2
sides = [
    (np.array([1, 0]), np.array([inner_x, inner_y])),                     # вниз по нижней
    (np.array([0, 1]), np.array([inner_x + inner_L, inner_y])),          # вверх по правой
    (np.array([-1, 0]), np.array([inner_x + inner_L, inner_y + inner_L])),# влево по верхней
    (np.array([0, -1]), np.array([inner_x, inner_y + inner_L])),         # вниз по левой
]
side_lengths = [inner_L] * 4
total_length = sum(side_lengths)

# Вычисление позиции солдата на маршруте
def compute_position(t, offset, normal_dir):
    t = t % total_length
    for (dir_vec, start), length in zip(sides, side_lengths):
        if t < length:
            # Смещение от контура наружу по нормали
            normal = np.array([-dir_vec[1], dir_vec[0]])
            return start + dir_vec * t + normal * offset
        t -= length
    return np.array([0, 0])  # не должно случаться

# Создание сцены
fig, ax = plt.subplots(figsize=(6, 6))
ax.set_xlim(0, L)
ax.set_ylim(0, L)
ax.set_aspect('equal')
ax.grid(True)

# Вырезанный квадрат
inner_square = Rectangle((inner_x, inner_y), inner_L, inner_L,
                         facecolor='white', edgecolor='black')
ax.add_patch(inner_square)

# Шарики (солдаты)
circles = []
soldiers = []
for r in range(rows):
    offset = (r + 0.5) * spacing
    for i in range(soldiers_per_side * 4):
        t = i * inner_L / soldiers_per_side
        normal_dir = 1  # наружу
        pos = compute_position(t, offset * normal_dir, normal_dir)
        circle = Circle(pos, radius=0.07, color='blue')
        ax.add_patch(circle)
        circles.append(circle)
        soldiers.append({'t': t, 'offset': offset, 'normal_dir': normal_dir})

# Анимация
def update(frame):
    speed = 0.12
    for soldier, circle in zip(soldiers, circles):
        soldier['t'] += speed
        pos = compute_position(soldier['t'], soldier['offset'], soldier['normal_dir'])
        circle.center = pos
    return circles

ani = animation.FuncAnimation(fig, update, frames=500, interval=40, blit=True)
plt.title("Строй солдат по периметру квадрата")
plt.tight_layout()
plt.show()
