public interface E {

    Object pp();

    java.util.List<String> jj();
}
