public class G extends null {

    void aa();

    String nn();

    public float ff() {
        return 3.14;
    }

    public double ee() {
        return java.lang.Math.PI;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }
}
