public class E extends null {

    Object pp();

    java.util.List<String> jj();

    public double ad() {
        return 11;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public long dd() {
        return 33;
    }

    public long ac() {
        return 222;
    }
}
