public class G extends null {

    void aa();

    String nn();

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public int cc() {
        return 13;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public void ab() {
        return;
    }

    public long ac() {
        return 111;
    }

    public double ad() {
        return 11;
    }

    public Object pp() {
        return this;
    }

    public String kk() {
        return "No";
    }
}
