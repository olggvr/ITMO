public class K extends null implements G {

    private int i = 1;

    private int c = 42;

    public float ff() {
        return 0;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public void aa() {
        return;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public long dd() {
        return 33;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public double ad() {
        return 9.11;
    }

    public Object rr() {
        return null;
    }

    public Object pp() {
        return this;
    }

    public double ee() {
        return 100.500;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public int af() {
        return -1;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public String kk() {
        return "No";
    }

    public void ab() {
        System.out.println();
    }

    public int cc() {
        return 42;
    }
}
