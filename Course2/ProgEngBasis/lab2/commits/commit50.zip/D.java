public class D extends K {

    private int k = 1;

    private long d = 4321;

    public long dd() {
        return 33;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public int cc() {
        return 42;
    }

    public Object rr() {
        return null;
    }

    public String kk() {
        return "Yes";
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public void ab() {
        System.out.println();
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public Object pp() {
        return this;
    }

    public long ac() {
        return 222;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public byte oo() {
        return 2;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public double ee() {
        return 0.000001;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public int af() {
        return -1;
    }
}
