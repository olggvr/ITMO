public class E extends null {

    Object pp();

    java.util.List<String> jj();

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public int ae() {
        return 8;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public long ac() {
        return 222;
    }

    public int cc() {
        return 42;
    }

    public void bb() {
        System.out.println(42);
    }
}
