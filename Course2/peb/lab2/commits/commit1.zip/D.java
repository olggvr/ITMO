public class D extends K {

    private int k = 1;

    private long d = 4321;

    public long dd() {
        return 33;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public void ab() {
        System.out.println();
    }
}
