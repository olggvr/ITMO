public interface G {

    void aa();

    String nn();
}
