public class D extends K {

    private int k = 1;

    private long d = 4321;

    public long dd() {
        return 33;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public void ab() {
        System.out.println();
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }

    public Object gg() {
        return new java.util.Random();
    }

    public Object rr() {
        return null;
    }
}
