public class G extends null {

    void aa();

    String nn();

    public Object rr() {
        return null;
    }

    public int cc() {
        return 42;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }
}
