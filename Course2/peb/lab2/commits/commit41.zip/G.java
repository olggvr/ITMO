public class G extends null {

    void aa();

    String nn();

    public double ee() {
        return java.lang.Math.PI;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public byte oo() {
        return 1;
    }

    public Object rr() {
        return null;
    }
}
