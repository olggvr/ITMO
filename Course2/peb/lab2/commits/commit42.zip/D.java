public class D extends K {

    private int k = 1;

    private long d = 4321;

    public long dd() {
        return 33;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public void ab() {
        System.out.println();
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public void bb() {
        System.out.println(42);
    }

    public Object rr() {
        return null;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public byte oo() {
        return 1;
    }

    public String kk() {
        return "Yes";
    }

    public int cc() {
        return 39;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }
}
