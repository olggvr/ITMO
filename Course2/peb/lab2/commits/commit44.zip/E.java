public class E extends null {

    Object pp();

    java.util.List<String> jj();

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public long dd() {
        return 33;
    }

    public Object rr() {
        return null;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public int ae() {
        return 8;
    }
}
