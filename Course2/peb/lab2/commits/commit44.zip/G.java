public class G extends null {

    void aa();

    String nn();

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public long dd() {
        return 33;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public int af() {
        return -1;
    }

    public void ab() {
        System.out.println("\n");
    }
}
