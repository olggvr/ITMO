public class K extends null implements G {

    private int i = 1;

    private int c = 42;

    public float ff() {
        return 0;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public void aa() {
        return;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public long dd() {
        return 33;
    }

    public double ad() {
        return 9.11;
    }

    public Object rr() {
        return null;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public Object gg() {
        return new java.util.Random();
    }

    public int ae() {
        return 9;
    }

    public double ee() {
        return java.lang.Math.PI;
    }

    public int cc() {
        return 13;
    }

    public void ab() {
        System.out.println();
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public String kk() {
        return "Yes";
    }

    public byte oo() {
        return 3;
    }
}
