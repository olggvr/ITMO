public class E extends null {

    Object pp();

    java.util.List<String> jj();

    public int ae() {
        return 9;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public float ff() {
        return 3.14;
    }

    public String kk() {
        return "No";
    }

    public void ab() {
        System.out.println();
    }

    public void bb() {
        System.out.println(42);
    }
}
