public class G extends null {

    void aa();

    String nn();

    public Object rr() {
        return null;
    }

    public int cc() {
        return 42;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public long ac() {
        return 222;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }
}
