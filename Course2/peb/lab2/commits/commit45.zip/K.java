public class K extends null implements G {

    private int i = 1;

    private int c = 42;

    public float ff() {
        return 0;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public void aa() {
        return;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public long dd() {
        return 33;
    }

    public double ad() {
        return 9.11;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public long ac() {
        return 111;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public int cc() {
        return 13;
    }

    public int af() {
        return -1;
    }

    public int ae() {
        return 8;
    }

    public String kk() {
        return "Yes";
    }

    public java.lang.Class qq() {
        return getClass();
    }
}
