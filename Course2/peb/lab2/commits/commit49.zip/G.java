public class G extends null {

    void aa();

    String nn();
}
