public class K extends null implements G {

    private int i = 1;

    private int c = 42;

    public float ff() {
        return 0;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public void aa() {
        return;
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public long dd() {
        return 33;
    }

    public double ad() {
        return 9.11;
    }

    public Object rr() {
        return null;
    }
}
